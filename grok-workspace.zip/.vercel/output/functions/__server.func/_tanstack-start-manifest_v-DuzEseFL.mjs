//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DuzEseFL.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/budget",
			"/expenses",
			"/join",
			"/login",
			"/onboarding",
			"/settings",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-BatxuaLz.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/preload-helper-CMS_b3zF.js",
			"/assets/link-BUbpN8P3.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BatxuaLz.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B2ZbrUk8.js",
			"/assets/app-shell-DXAfdVIO.js",
			"/assets/types-fp1ZsiZz.js",
			"/assets/label-Dcd7DDY2.js",
			"/assets/category-bar-BslSpUXY.js",
			"/assets/expense-row-uvWT-O6F.js"
		]
	},
	"/budget": {
		filePath: "/workspace/src/routes/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-BkmTZliR.js",
			"/assets/app-shell-DXAfdVIO.js",
			"/assets/types-fp1ZsiZz.js",
			"/assets/label-Dcd7DDY2.js",
			"/assets/category-bar-BslSpUXY.js"
		]
	},
	"/expenses": {
		filePath: "/workspace/src/routes/expenses.tsx",
		children: void 0,
		preloads: [
			"/assets/expenses-Mm2V_rm6.js",
			"/assets/app-shell-DXAfdVIO.js",
			"/assets/types-fp1ZsiZz.js",
			"/assets/label-Dcd7DDY2.js",
			"/assets/expense-row-uvWT-O6F.js"
		]
	},
	"/join": {
		filePath: "/workspace/src/routes/join.tsx",
		children: void 0,
		preloads: [
			"/assets/join-BBNganm5.js",
			"/assets/label-Dcd7DDY2.js",
			"/assets/member-dot-B5n9kIk2.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-WcaTMS3S.js",
			"/assets/label-Dcd7DDY2.js",
			"/assets/client-DRhaju3Z.js"
		]
	},
	"/onboarding": {
		filePath: "/workspace/src/routes/onboarding.tsx",
		children: void 0,
		preloads: ["/assets/onboarding-DsuLsgOS.js", "/assets/label-Dcd7DDY2.js"]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-Ct0opMb3.js",
			"/assets/app-shell-DXAfdVIO.js",
			"/assets/label-Dcd7DDY2.js",
			"/assets/client-DRhaju3Z.js",
			"/assets/member-dot-B5n9kIk2.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
