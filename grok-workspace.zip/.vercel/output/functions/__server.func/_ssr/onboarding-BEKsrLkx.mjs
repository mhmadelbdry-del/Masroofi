import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate, v as Link, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Label, f as useMasroufiMutations, i as Input, m as useSnapshot, n as Button, o as Logo, s as Splash, t as AuthGate } from "./label-C-91Zdo4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/onboarding-BEKsrLkx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OnboardingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OnboardingForm, {}) });
}
function OnboardingForm() {
	const { data, isPending } = useSnapshot();
	const nav = useNavigate();
	const mut = useMasroufiMutations();
	const [selfName, setSelfName] = (0, import_react.useState)("محمد");
	const [partnerName, setPartnerName] = (0, import_react.useState)("إسراء");
	const [income, setIncome] = (0, import_react.useState)("20000");
	const [goal, setGoal] = (0, import_react.useState)("7000");
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (data?.household) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { withWord: true }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 text-2xl font-semibold",
						children: "إعداد الأسرة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "اسمك، اسم زوجتك، والدخل الشهري. بعدها يصير الدفتر جاهزاً على جواليكما."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "paper-card space-y-3 rounded-xl p-5",
				onSubmit: async (e) => {
					e.preventDefault();
					try {
						await mut.create.mutateAsync({
							selfName: selfName.trim(),
							partnerName: partnerName.trim(),
							monthlyIncome: Number(income) || 0,
							savingsGoal: Number(goal) || 0
						});
						await nav({ to: "/" });
					} catch {}
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "self",
							children: "اسمك"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "self",
							value: selfName,
							onChange: (e) => setSelfName(e.target.value),
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "partner",
							children: "اسم زوجتك / زوجك"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "partner",
							value: partnerName,
							onChange: (e) => setPartnerName(e.target.value),
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "income",
							children: "الدخل الشهري"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "income",
							type: "number",
							min: "0",
							value: income,
							onChange: (e) => setIncome(e.target.value),
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "goal",
							children: "هدف الادخار الشهري"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "goal",
							type: "number",
							min: "0",
							value: goal,
							onChange: (e) => setGoal(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "w-full",
						disabled: mut.create.isPending,
						children: mut.create.isPending ? "نجهّز الدفتر…" : "ابدأ مصروفي"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-5 text-center text-sm text-muted",
				children: [
					"شريكك أنشأ البيت مسبقاً؟",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/join",
						className: "font-medium text-primary",
						children: "أدخل رمز الانضمام"
					})
				]
			})
		]
	});
}
//#endregion
export { OnboardingPage as component };
