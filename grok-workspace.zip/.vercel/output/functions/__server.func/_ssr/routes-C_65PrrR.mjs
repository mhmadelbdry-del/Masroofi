import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as daysLeftInMonth, l as shiftMonth, o as formatMoney, s as formatMonthTitle } from "./format-BkDqXsC0.mjs";
import { d as ChevronRight, f as ChevronLeft, s as Plus } from "../_libs/lucide-react.mjs";
import { c as cn, f as useMasroufiMutations, m as useSnapshot, n as Button, p as useMonth, r as HouseholdGate, t as AuthGate } from "./label-C-91Zdo4.mjs";
import { t as AppShell } from "./app-shell-UNqL5uTK.mjs";
import { n as DialogContent, t as Dialog } from "./types-5Gk2wD6h.mjs";
import { n as CategoryBar, t as Badge } from "./category-bar-BRwW7yUE.mjs";
import { n as ExpenseRow, t as ExpenseForm } from "./expense-row-o4k20FVm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C_65PrrR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-24 w-full rounded-md border border-border bg-surface px-3 py-2.5 text-base text-fg outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-subtle focus:border-primary focus:ring-2 focus:ring-ring/20 disabled:opacity-50", className),
		...props
	});
}
function SummaryView() {
	const { year, month, setMonth } = useMonth();
	const { data } = useSnapshot();
	const mut = useMasroufiMutations();
	const [note, setNote] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(null);
	if (!data?.household || !data.me) return null;
	const spent = data.expenses.reduce((s, e) => s + e.amount, 0);
	const remaining = data.household.monthlyIncome - spent;
	const left = daysLeftInMonth(year, month);
	const goalMet = remaining >= data.household.savingsGoal && data.household.savingsGoal > 0;
	const reflection = note ?? data.reflection;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-xl font-semibold",
					children: ["ملخص ", formatMonthTitle(year, month)]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-full hover:bg-bg-warm",
						onClick: () => {
							const n = shiftMonth(year, month, -1);
							setMonth(n.year, n.month);
						},
						"aria-label": "الشهر السابق",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-full hover:bg-bg-warm",
						onClick: () => {
							const n = shiftMonth(year, month, 1);
							setMonth(n.year, n.month);
						},
						"aria-label": "الشهر التالي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "hero-panel rounded-xl p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-hero-muted",
						children: "المتبقي للإنفاق حتى نهاية الشهر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "num mt-1 text-4xl font-semibold tracking-tight",
						children: formatMoney(remaining)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-hero-muted",
						children: left > 0 ? `باقي ${left} يوم` : "انتهى الشهر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
								label: "الدخل",
								value: formatMoney(data.household.monthlyIncome)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
								label: "إجمالي المصروف",
								value: formatMoney(spent)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
								label: "هدف الادخار",
								value: formatMoney(data.household.savingsGoal),
								hint: goalMet ? "تحقق" : void 0
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "paper-card rounded-lg p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "تسجيل سريع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 text-subtle" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseForm, {
					categories: data.categories,
					me: data.me,
					pending: mut.add.isPending,
					onSubmit: (payload) => mut.add.mutate(payload)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "متابعة فئات الميزانية"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/budget",
						className: "text-sm text-primary",
						children: "إدارة الحدود"
					})]
				}), data.categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryBar, { category: c }, c.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "paper-card rounded-lg p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "تأمل وانعاش الشهر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 mb-3 text-sm text-muted",
						children: "مساحة هادئة لمراجعة ما كان ممتعاً وما يمكن ترشيده في الشهر القادم."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: reflection,
						onChange: (e) => setNote(e.target.value),
						placeholder: "مثال: أسعدنا رحلة نهاية الأسبوع. الشهر القادم سنقلل طلبات المطاعم."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3 w-full",
						variant: "secondary",
						disabled: mut.reflection.isPending,
						onClick: () => mut.reflection.mutate({
							year,
							month,
							note: reflection
						}),
						children: "حفظ التأمل الشهري"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "آخر العمليات المقيدة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/expenses",
						className: "text-sm text-primary",
						children: "كل المصروفات"
					})]
				}), data.expenses.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "paper-card rounded-lg p-6 text-center text-sm text-muted",
					children: "لا مصروفات في هذا الشهر بعد."
				}) : data.expenses.slice(0, 6).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseRow, {
					expense: e,
					onClick: () => setEditing(e)
				}, e.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(editing),
				onOpenChange: (o) => !o && setEditing(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					title: "تعديل المصروف",
					children: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseForm, {
							categories: data.categories,
							me: data.me,
							initial: {
								description: editing.description,
								amount: editing.amount,
								categoryId: editing.categoryId
							},
							pending: mut.update.isPending,
							submitLabel: "حفظ التعديل",
							onSubmit: (payload) => {
								mut.update.mutate({
									id: editing.id,
									...payload
								});
								setEditing(null);
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "w-full text-danger",
							onClick: () => {
								mut.remove.mutate(editing.id);
								setEditing(null);
							},
							children: "حذف المصروف"
						})]
					}) : null
				})
			})
		]
	});
}
function HeroStat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-surface/10 px-2.5 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-hero-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "num mt-0.5 text-sm font-semibold",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				tone: "hero",
				className: "mt-1",
				children: hint
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseholdGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryView, {}) }) }) });
}
//#endregion
export { Home as component };
