import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as usageTone, o as formatMoney, u as usagePct } from "./format-BkDqXsC0.mjs";
import { c as cn } from "./label-C-91Zdo4.mjs";
import { r as KIND_LABEL } from "./types-5Gk2wD6h.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category-bar-BRwW7yUE.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "muted", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", tone === "muted" && "bg-bg-warm text-muted", tone === "ok" && "bg-ok-soft text-ok", tone === "warn" && "bg-warn-soft text-warn", tone === "over" && "bg-danger-soft text-danger", tone === "hero" && "bg-surface/15 text-hero-muted", className),
		...props
	});
}
var TONE_LABEL = {
	ok: "ضمن الحد",
	warn: "قارب الحد",
	over: "تجاوز الحد"
};
function CategoryBar({ category, onEdit }) {
	const tone = usageTone(category.spent, category.monthlyLimit);
	const pct = usagePct(category.spent, category.monthlyLimit);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "paper-card rounded-lg p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold text-fg",
					children: category.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-xs text-subtle",
					children: KIND_LABEL[category.kind]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone,
					children: TONE_LABEL[tone]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-end justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: ["السقف ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "num font-medium text-fg",
						children: formatMoney(category.monthlyLimit)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: ["تم صرف ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "num font-semibold text-fg",
						children: formatMoney(category.spent)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-2 overflow-hidden rounded-full bg-bg-warm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("h-full rounded-full transition-[width] duration-300", tone === "ok" && "bg-primary", tone === "warn" && "bg-warn", tone === "over" && "bg-danger"),
					style: { width: `${pct}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-subtle",
					children: [
						"استهلاك ",
						pct,
						"%"
					]
				}), onEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onEdit,
					className: "text-xs font-medium text-primary hover:underline",
					children: "تعديل الحد"
				}) : null]
			})
		]
	});
}
//#endregion
export { CategoryBar as n, Badge as t };
