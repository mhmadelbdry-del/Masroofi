import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as signOut } from "./client-B40BzJxt.mjs";
import { c as LogOut, u as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Label, c as cn, f as useMasroufiMutations, i as Input, l as useCurrentUser, m as useSnapshot, n as Button, r as HouseholdGate, t as AuthGate } from "./label-C-91Zdo4.mjs";
import { t as MemberDot } from "./member-dot-BcqBOtJn.mjs";
import { t as AppShell } from "./app-shell-UNqL5uTK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-D5eZ1GXj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsView() {
	const user = useCurrentUser();
	const { data } = useSnapshot();
	const mut = useMasroufiMutations();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	if (!data?.household || !data.me) return null;
	const [income, setIncome] = (0, import_react.useState)(String(data.household.monthlyIncome));
	const [goal, setGoal] = (0, import_react.useState)(String(data.household.savingsGoal));
	const [names, setNames] = (0, import_react.useState)(data.members.map((m) => ({
		id: m.id,
		name: m.name
	})));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-xl font-semibold",
				children: "إعداد الأسرة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "paper-card rounded-lg p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 font-semibold",
						children: "المستخدم الحالي على هذا الجهاز"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: "كل قيد جديد يُسجَّل باسم من تختاره هنا، مع التاريخ والوقت تلقائياً."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: data.members.map((m) => {
							const active = m.id === data.me?.memberId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => mut.member.mutate(m.id),
								className: cn("flex items-center gap-2 rounded-md px-3 py-3 text-right", active ? "bg-primary text-primary-fg" : "bg-bg-warm text-fg"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberDot, {
									name: m.name,
									size: "sm",
									active
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: m.name
								})]
							}, m.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "paper-card rounded-lg p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-1 font-semibold",
						children: "رمز مزامنة البيت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: "شارك هذا الرمز مع زوجك/زوجتك. بعد تسجيل الدخول يدخله ليرى نفس الدفتر فوراً."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "num flex-1 rounded-md bg-bg-warm px-3 py-3 text-center text-lg font-semibold tracking-widest",
							children: data.household.joinCode
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							onClick: async () => {
								try {
									await navigator.clipboard.writeText(data.household.joinCode);
									toast.success("تم نسخ الرمز");
								} catch {
									toast.error("تعذر النسخ");
								}
							},
							"aria-label": "نسخ الرمز",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "paper-card space-y-3 rounded-lg p-4",
				onSubmit: (e) => {
					e.preventDefault();
					mut.household.mutate({
						monthlyIncome: Number(income) || 0,
						savingsGoal: Number(goal) || 0,
						members: names
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "الدخل والأسماء"
					}),
					names.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `n-${m.id}`,
							children: i === 0 ? "الاسم الأول" : "اسم الشريك"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `n-${m.id}`,
							value: m.name,
							onChange: (e) => setNames((prev) => prev.map((x) => x.id === m.id ? {
								...x,
								name: e.target.value
							} : x))
						})]
					}, m.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "income",
							children: "الدخل الشهري"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "income",
							type: "number",
							min: "0",
							value: income,
							onChange: (e) => setIncome(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "goal",
							children: "هدف الادخار الشهري"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "goal",
							type: "number",
							min: "0",
							value: goal,
							onChange: (e) => setGoal(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "w-full",
						disabled: mut.household.isPending,
						children: "حفظ الإعدادات"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "paper-card rounded-lg p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["الحساب: ", user?.displayName ?? user?.primaryEmail ?? "—"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					className: "mt-3 w-full",
					disabled: signingOut,
					onClick: () => {
						setSigningOut(true);
						signOut().catch(() => setSigningOut(false));
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), signingOut ? "جارٍ الخروج…" : "تسجيل الخروج"]
				})]
			})
		]
	});
}
function SettingsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseholdGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}) }) }) });
}
//#endregion
export { SettingsPage as component };
