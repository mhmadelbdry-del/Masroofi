import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-BkDqXsC0.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-B40BzJxt.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-DCoGw2KN.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var MONEY = new Intl.NumberFormat("ar-EG", {
	numberingSystem: "latn",
	minimumFractionDigits: 0,
	maximumFractionDigits: 2
});
var MONEY_FIXED = new Intl.NumberFormat("ar-EG", {
	numberingSystem: "latn",
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
var CAIRO = "Africa/Cairo";
function formatMoney(value, opts) {
	if (!Number.isFinite(value)) return "0";
	return (opts?.fixed ? MONEY_FIXED : MONEY).format(value);
}
function cairoParts(date = /* @__PURE__ */ new Date()) {
	const parts = new Intl.DateTimeFormat("en-GB", {
		timeZone: CAIRO,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).formatToParts(date);
	const pick = (type) => Number(parts.find((p) => p.type === type)?.value ?? "0");
	return {
		year: pick("year"),
		month: pick("month"),
		day: pick("day")
	};
}
function tzOffsetMs(date, timeZone) {
	const dtf = new Intl.DateTimeFormat("en-US", {
		timeZone,
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hourCycle: "h23"
	});
	const parts = Object.fromEntries(dtf.formatToParts(date).map((p) => [p.type, p.value]));
	return Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day), Number(parts.hour), Number(parts.minute), Number(parts.second)) - date.getTime();
}
function cairoLocalToDate(year, month, day, hour = 0, minute = 0) {
	const guess = Date.UTC(year, month - 1, day, hour, minute, 0);
	const date = new Date(guess);
	return new Date(guess - tzOffsetMs(date, CAIRO));
}
function formatMonthTitle(year, month) {
	const d = new Date(Date.UTC(year, month - 1, 1));
	return new Intl.DateTimeFormat("ar-EG", {
		month: "long",
		year: "numeric",
		numberingSystem: "latn",
		timeZone: "UTC"
	}).format(d);
}
function formatExpenseWhen(iso) {
	const d = new Date(iso);
	return {
		date: new Intl.DateTimeFormat("ar-EG", {
			day: "2-digit",
			month: "2-digit",
			numberingSystem: "latn",
			timeZone: CAIRO
		}).format(d),
		time: new Intl.DateTimeFormat("ar-EG", {
			hour: "2-digit",
			minute: "2-digit",
			hour12: false,
			numberingSystem: "latn",
			timeZone: CAIRO
		}).format(d)
	};
}
function daysLeftInMonth(year, month) {
	const { year: cy, month: cm, day } = cairoParts();
	const last = new Date(year, month, 0).getDate();
	if (year === cy && month === cm) return Math.max(0, last - day);
	if (year > cy || year === cy && month > cm) return last;
	return 0;
}
function monthBoundsIso(year, month) {
	const start = cairoLocalToDate(year, month, 1, 0, 0);
	const endMonth = month === 12 ? 1 : month + 1;
	const end = cairoLocalToDate(month === 12 ? year + 1 : year, endMonth, 1, 0, 0);
	return {
		start: start.toISOString(),
		end: end.toISOString()
	};
}
function shiftMonth(year, month, delta) {
	const d = new Date(year, month - 1 + delta, 1);
	return {
		year: d.getFullYear(),
		month: d.getMonth() + 1
	};
}
function usageTone(spent, limit) {
	if (limit <= 0) return spent > 0 ? "over" : "ok";
	const ratio = spent / limit;
	if (ratio >= 1) return "over";
	if (ratio >= .85) return "warn";
	return "ok";
}
function usagePct(spent, limit) {
	if (limit <= 0) return spent > 0 ? 100 : 0;
	return Math.min(100, Math.round(spent / limit * 100));
}
//#endregion
export { formatExpenseWhen as a, monthBoundsIso as c, usageTone as d, daysLeftInMonth as i, shiftMonth as l, cairoLocalToDate as n, formatMoney as o, cairoParts as r, formatMonthTitle as s, authMiddleware as t, usagePct as u };
