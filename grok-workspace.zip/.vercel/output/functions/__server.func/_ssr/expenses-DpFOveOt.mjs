import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { s as formatMonthTitle } from "./format-BkDqXsC0.mjs";
import { s as Plus } from "../_libs/lucide-react.mjs";
import { f as useMasroufiMutations, m as useSnapshot, n as Button, p as useMonth, r as HouseholdGate, t as AuthGate } from "./label-C-91Zdo4.mjs";
import { t as AppShell } from "./app-shell-UNqL5uTK.mjs";
import { n as DialogContent, t as Dialog } from "./types-5Gk2wD6h.mjs";
import { n as ExpenseRow, t as ExpenseForm } from "./expense-row-o4k20FVm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/expenses-DpFOveOt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ExpensesView() {
	const { year, month } = useMonth();
	const { data } = useSnapshot();
	const mut = useMasroufiMutations();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const list = (0, import_react.useMemo)(() => {
		if (!data) return [];
		if (filter === "all") return data.expenses;
		return data.expenses.filter((e) => e.categoryId === filter);
	}, [data, filter]);
	if (!data?.household || !data.me) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold",
					children: "المصروفات اليومية"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: formatMonthTitle(year, month)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "قيد جديد"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "paper-card rounded-lg p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-semibold",
					children: "إضافة سريعة لمصروف"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseForm, {
					categories: data.categories,
					me: data.me,
					pending: mut.add.isPending,
					onSubmit: (payload) => mut.add.mutate(payload)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "سجل العمليات الأخير"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: filter,
						onChange: (e) => setFilter(e.target.value),
						className: "h-9 rounded-md border border-border bg-surface px-2 text-xs text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "كل الفئات"
						}), data.categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))]
					})]
				}), list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "paper-card rounded-lg p-8 text-center text-sm text-muted",
					children: "لا توجد عمليات في هذا العرض."
				}) : list.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseRow, {
					expense: e,
					onClick: () => setEditing(e)
				}, e.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					title: "قيد جديد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseForm, {
						categories: data.categories,
						me: data.me,
						pending: mut.add.isPending,
						onSubmit: (payload) => {
							mut.add.mutate(payload);
							setOpen(false);
						}
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(editing),
				onOpenChange: (o) => !o && setEditing(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					title: "تعديل المصروف",
					children: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseForm, {
							categories: data.categories,
							me: data.me,
							initial: {
								description: editing.description,
								amount: editing.amount,
								categoryId: editing.categoryId
							},
							pending: mut.update.isPending,
							submitLabel: "حفظ التعديل",
							onSubmit: (payload) => {
								mut.update.mutate({
									id: editing.id,
									...payload
								});
								setEditing(null);
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "w-full text-danger",
							onClick: () => {
								mut.remove.mutate(editing.id);
								setEditing(null);
							},
							children: "حذف المصروف"
						})]
					}) : null
				})
			})
		]
	});
}
function ExpensesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseholdGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpensesView, {}) }) }) });
}
//#endregion
export { ExpensesPage as component };
