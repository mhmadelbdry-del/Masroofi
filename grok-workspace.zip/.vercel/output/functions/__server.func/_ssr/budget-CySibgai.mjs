import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as usageTone, o as formatMoney } from "./format-BkDqXsC0.mjs";
import { s as Plus } from "../_libs/lucide-react.mjs";
import { a as Label, c as cn, f as useMasroufiMutations, i as Input, m as useSnapshot, n as Button, r as HouseholdGate, t as AuthGate } from "./label-C-91Zdo4.mjs";
import { t as AppShell } from "./app-shell-UNqL5uTK.mjs";
import { n as DialogContent, r as KIND_LABEL, t as Dialog } from "./types-5Gk2wD6h.mjs";
import { n as CategoryBar } from "./category-bar-BRwW7yUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/budget-CySibgai.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "all",
		label: "الكل"
	},
	{
		id: "necessity",
		label: "الضروريات"
	},
	{
		id: "extra",
		label: "الكماليات"
	},
	{
		id: "over",
		label: "تجاوز الحد"
	}
];
function BudgetView() {
	const { data } = useSnapshot();
	const mut = useMasroufiMutations();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const list = (0, import_react.useMemo)(() => {
		if (!data) return [];
		if (filter === "all") return data.categories;
		if (filter === "over") return data.categories.filter((c) => usageTone(c.spent, c.monthlyLimit) === "over");
		return data.categories.filter((c) => c.kind === filter);
	}, [data, filter]);
	if (!data?.household) return null;
	const cap = data.categories.reduce((s, c) => s + c.monthlyLimit, 0);
	const spent = data.categories.reduce((s, c) => s + c.spent, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold",
					children: "حدود الميزانية"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setEditing("new"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "فئة جديدة"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "paper-card rounded-lg p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "إجمالي السقف الشهري"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "num mt-1 text-2xl font-semibold",
						children: formatMoney(cap)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "paper-card rounded-lg p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "إجمالي المصروف الفعلي"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "num mt-1 text-2xl font-semibold",
							children: formatMoney(spent)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-subtle",
							children: [data.categories.length, " فئات"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(f.id),
					className: cn("h-9 shrink-0 rounded-full px-3 text-sm font-medium", filter === f.id ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-card"),
					children: f.label
				}, f.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "paper-card rounded-lg p-8 text-center text-sm text-muted",
					children: "لا فئات في هذا التبويب."
				}) : list.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryBar, {
					category: c,
					onEdit: () => setEditing(c)
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "paper-card rounded-lg p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-semibold",
					children: "تعديل سريع لحد فئة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickLimit, {
					categories: data.categories,
					onSave: (payload) => mut.saveCat.mutate(payload),
					pending: mut.saveCat.isPending
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(editing),
				onOpenChange: (o) => !o && setEditing(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					title: editing === "new" ? "فئة جديدة" : "تعديل الفئة",
					children: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryForm, {
						initial: editing === "new" ? void 0 : editing,
						pending: mut.saveCat.isPending,
						onSubmit: (payload) => {
							mut.saveCat.mutate(payload);
							setEditing(null);
						},
						onArchive: editing !== "new" && editing.id ? () => {
							mut.hideCat.mutate(editing.id);
							setEditing(null);
						} : void 0
					}) : null
				})
			})
		]
	});
}
function QuickLimit({ categories, onSave, pending }) {
	const [id, setId] = (0, import_react.useState)("");
	const [limit, setLimit] = (0, import_react.useState)("");
	const selected = categories.find((c) => c.id === id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-3",
		onSubmit: (e) => {
			e.preventDefault();
			if (!selected) return;
			const monthlyLimit = Number(limit);
			if (!Number.isFinite(monthlyLimit) || monthlyLimit < 0) return;
			onSave({
				id: selected.id,
				name: selected.name,
				kind: selected.kind,
				monthlyLimit
			});
			setLimit("");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "ql-cat",
					children: "اختر الفئة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					id: "ql-cat",
					value: id,
					onChange: (e) => {
						setId(e.target.value);
						const c = categories.find((x) => x.id === e.target.value);
						setLimit(c ? String(c.monthlyLimit) : "");
					},
					className: "flex h-11 w-full rounded-md border border-border bg-surface px-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "اختر…"
					}), categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: c.id,
						children: c.name
					}, c.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "ql-limit",
					children: "الحد الشهري الجديد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ql-limit",
					inputMode: "decimal",
					type: "number",
					min: "0",
					step: "1",
					value: limit,
					onChange: (e) => setLimit(e.target.value),
					placeholder: "مثال: 3200"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "w-full",
				disabled: pending || !id,
				children: "حفظ السقف الجديد للشهر"
			})
		]
	});
}
function CategoryForm({ initial, pending, onSubmit, onArchive }) {
	const [name, setName] = (0, import_react.useState)(initial?.name ?? "");
	const [kind, setKind] = (0, import_react.useState)(initial?.kind ?? "necessity");
	const [limit, setLimit] = (0, import_react.useState)(initial ? String(initial.monthlyLimit) : "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-3",
		onSubmit: (e) => {
			e.preventDefault();
			const monthlyLimit = Number(limit);
			if (!name.trim() || !Number.isFinite(monthlyLimit) || monthlyLimit < 0) return;
			onSubmit({
				id: initial?.id,
				name: name.trim(),
				kind,
				monthlyLimit
			});
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "cat-name",
					children: "اسم الفئة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "cat-name",
					value: name,
					onChange: (e) => setName(e.target.value),
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "cat-kind",
					children: "النوع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					id: "cat-kind",
					value: kind,
					onChange: (e) => setKind(e.target.value),
					className: "flex h-11 w-full rounded-md border border-border bg-surface px-3 text-sm",
					children: Object.keys(KIND_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: k,
						children: KIND_LABEL[k]
					}, k))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "cat-limit",
					children: "الحد المالي الشهري"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "cat-limit",
					type: "number",
					min: "0",
					step: "1",
					value: limit,
					onChange: (e) => setLimit(e.target.value),
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "w-full",
				disabled: pending,
				children: "حفظ الفئة"
			}),
			onArchive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				className: "w-full text-danger",
				onClick: onArchive,
				children: "إخفاء الفئة"
			}) : null
		]
	});
}
function BudgetPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseholdGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetView, {}) }) }) });
}
//#endregion
export { BudgetPage as component };
