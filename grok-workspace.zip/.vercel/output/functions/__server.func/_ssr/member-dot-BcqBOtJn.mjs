import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as cn } from "./label-C-91Zdo4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/member-dot-BcqBOtJn.js
var import_jsx_runtime = require_jsx_runtime();
function MemberDot({ name, size = "md", active = false }) {
	const initial = name.trim().charAt(0) || "؟";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid place-items-center rounded-full font-semibold", size === "sm" ? "size-7 text-xs" : "size-9 text-sm", active ? "bg-primary text-primary-fg" : "bg-primary-soft text-primary"),
		title: name,
		children: initial
	});
}
//#endregion
export { MemberDot as t };
