import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { c as monthBoundsIso, n as cairoLocalToDate, r as cairoParts, t as authMiddleware } from "./format-BkDqXsC0.mjs";
import { D as _enum, F as object, P as number, R as string, k as array } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-CpwHXeHW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/queries-BFRFvmHo.js
var DEFAULT_CATEGORIES = [
	{
		name: "بقالة وتموينات",
		kind: "necessity",
		monthlyLimit: 2800
	},
	{
		name: "لحوم ودواجن",
		kind: "necessity",
		monthlyLimit: 1200
	},
	{
		name: "علاج وصيدلية",
		kind: "necessity",
		monthlyLimit: 800
	},
	{
		name: "مواصلات ووقود",
		kind: "necessity",
		monthlyLimit: 900
	},
	{
		name: "كماليات ومطاعم",
		kind: "extra",
		monthlyLimit: 2e3
	},
	{
		name: "ثقافة وكتب",
		kind: "extra",
		monthlyLimit: 600
	},
	{
		name: "طوارئ وتصليحات",
		kind: "unexpected",
		monthlyLimit: 1e3
	}
];
var DEMO_EXPENSES = [
	{
		day: 3,
		hour: 11,
		minute: 20,
		description: "خضار وفاكهة الأسبوع",
		amount: 420,
		categoryIndex: 0,
		memberIndex: 1
	},
	{
		day: 4,
		hour: 18,
		minute: 5,
		description: "أرز وسكر وزيت",
		amount: 510,
		categoryIndex: 0,
		memberIndex: 0
	},
	{
		day: 6,
		hour: 16,
		minute: 40,
		description: "منظفات ومناديل",
		amount: 280,
		categoryIndex: 0,
		memberIndex: 1
	},
	{
		day: 8,
		hour: 10,
		minute: 15,
		description: "حليب وأجبان",
		amount: 195,
		categoryIndex: 0,
		memberIndex: 1
	},
	{
		day: 11,
		hour: 9,
		minute: 30,
		description: "مقهى ومخبوزات أسبوعية",
		amount: 115,
		categoryIndex: 4,
		memberIndex: 1
	},
	{
		day: 12,
		hour: 14,
		minute: 0,
		description: "إصلاح مفاجئ لمكيف الصالة",
		amount: 650,
		categoryIndex: 6,
		memberIndex: 0
	},
	{
		day: 13,
		hour: 19,
		minute: 10,
		description: "دجاج طازج",
		amount: 260,
		categoryIndex: 1,
		memberIndex: 0
	},
	{
		day: 14,
		hour: 16,
		minute: 20,
		description: "كتب للأطفال وقصص",
		amount: 180,
		categoryIndex: 5,
		memberIndex: 1
	},
	{
		day: 15,
		hour: 11,
		minute: 0,
		description: "شراء لحم بلدي للشهر",
		amount: 450,
		categoryIndex: 1,
		memberIndex: 0
	},
	{
		day: 16,
		hour: 20,
		minute: 10,
		description: "عشاء مطعم مع الأهل",
		amount: 480,
		categoryIndex: 4,
		memberIndex: 0
	},
	{
		day: 17,
		hour: 21,
		minute: 40,
		description: "صيدلية — حليب ومسكنات",
		amount: 120,
		categoryIndex: 2,
		memberIndex: 0
	},
	{
		day: 18,
		hour: 12,
		minute: 15,
		description: "بنزين سيارة العائلة",
		amount: 165,
		categoryIndex: 3,
		memberIndex: 0
	},
	{
		day: 18,
		hour: 17,
		minute: 30,
		description: "تموينات السوبرماركت",
		amount: 340.5,
		categoryIndex: 0,
		memberIndex: 1
	},
	{
		day: 19,
		hour: 8,
		minute: 45,
		description: "اشتراك مواصلات",
		amount: 350,
		categoryIndex: 3,
		memberIndex: 0
	},
	{
		day: 20,
		hour: 13,
		minute: 0,
		description: "فيتامينات وأدوية مزمنة",
		amount: 310,
		categoryIndex: 2,
		memberIndex: 1
	},
	{
		day: 21,
		hour: 15,
		minute: 25,
		description: "كبدة ودواجن",
		amount: 270,
		categoryIndex: 1,
		memberIndex: 0
	},
	{
		day: 22,
		hour: 19,
		minute: 50,
		description: "طلب طعام سريع",
		amount: 210,
		categoryIndex: 4,
		memberIndex: 1
	},
	{
		day: 23,
		hour: 10,
		minute: 5,
		description: "غاز ومنزل",
		amount: 400,
		categoryIndex: 6,
		memberIndex: 0
	},
	{
		day: 24,
		hour: 12,
		minute: 0,
		description: "وقود إضافي",
		amount: 220,
		categoryIndex: 3,
		memberIndex: 0
	},
	{
		day: 25,
		hour: 17,
		minute: 15,
		description: "مجلة وقصص",
		amount: 95,
		categoryIndex: 5,
		memberIndex: 1
	},
	{
		day: 26,
		hour: 20,
		minute: 40,
		description: "حلويات وضيافة",
		amount: 175,
		categoryIndex: 4,
		memberIndex: 1
	},
	{
		day: 27,
		hour: 9,
		minute: 10,
		description: "خبز ومخبوزات",
		amount: 85,
		categoryIndex: 0,
		memberIndex: 0
	}
];
function num(v) {
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : 0;
}
function iso(v) {
	if (v instanceof Date) return v.toISOString();
	return String(v);
}
function joinCode() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	const bytes = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6));
	return Array.from(bytes, (b) => alphabet[b % 32]).join("");
}
async function membership(sql, userId) {
	return (await sql`
    select
      hu.household_id,
      hu.member_id,
      m.name as member_name,
      h.monthly_income,
      h.savings_goal,
      h.join_code
    from household_users hu
    join households h on h.id = hu.household_id
    join household_members m on m.id = hu.member_id
    where hu.user_id = ${userId}
    limit 1
  `)[0] ?? null;
}
async function loadMembers(sql, householdId) {
	return (await sql`
    select
      m.id,
      m.name,
      m.sort_order,
      exists(select 1 from household_users u where u.member_id = m.id) as claimed
    from household_members m
    where m.household_id = ${householdId}
    order by m.sort_order asc
  `).map((r) => ({
		id: r.id,
		name: r.name,
		sortOrder: num(r.sort_order),
		claimed: r.claimed === true || r.claimed === "t" || r.claimed === "true"
	}));
}
async function loadSnapshot(sql, userId, year, month) {
	const mine = await membership(sql, userId);
	if (!mine) return {
		household: null,
		members: [],
		me: null,
		categories: [],
		expenses: [],
		reflection: "",
		year,
		month
	};
	const { start, end } = monthBoundsIso(year, month);
	const hid = mine.household_id;
	const [members, catRows, expRows, refRows] = await Promise.all([
		loadMembers(sql, hid),
		sql`
      select
        c.id,
        c.name,
        c.kind,
        c.monthly_limit,
        c.sort_order,
        coalesce((
          select sum(e.amount) from expenses e
          where e.category_id = c.id
            and e.household_id = ${hid}
            and e.occurred_at >= ${start}::timestamptz
            and e.occurred_at < ${end}::timestamptz
        ), 0) as spent
      from categories c
      where c.household_id = ${hid} and c.archived = false
      order by c.sort_order asc
    `,
		sql`
      select
        e.id,
        e.category_id,
        c.name as category_name,
        c.kind as category_kind,
        e.description,
        e.amount,
        e.occurred_at,
        e.created_by_member_id,
        cm.name as created_by_name,
        e.updated_by_member_id,
        um.name as updated_by_name
      from expenses e
      join categories c on c.id = e.category_id
      join household_members cm on cm.id = e.created_by_member_id
      join household_members um on um.id = e.updated_by_member_id
      join household_users hu on hu.household_id = e.household_id
      where hu.user_id = ${userId}
        and e.occurred_at >= ${start}::timestamptz
        and e.occurred_at < ${end}::timestamptz
      order by e.occurred_at desc
    `,
		sql`
      select note from reflections
      where household_id = ${hid} and year = ${year} and month = ${month}
      limit 1
    `
	]);
	const categories = catRows.map((c) => ({
		id: c.id,
		name: c.name,
		kind: c.kind,
		monthlyLimit: num(c.monthly_limit),
		sortOrder: num(c.sort_order),
		spent: num(c.spent)
	}));
	const expenses = expRows.map((e) => ({
		id: e.id,
		categoryId: e.category_id,
		categoryName: e.category_name,
		categoryKind: e.category_kind,
		description: e.description,
		amount: num(e.amount),
		occurredAt: iso(e.occurred_at),
		createdByMemberId: e.created_by_member_id,
		createdByName: e.created_by_name,
		updatedByMemberId: e.updated_by_member_id,
		updatedByName: e.updated_by_name
	}));
	return {
		household: {
			id: hid,
			monthlyIncome: num(mine.monthly_income),
			savingsGoal: num(mine.savings_goal),
			joinCode: mine.join_code
		},
		members,
		me: {
			memberId: mine.member_id,
			name: mine.member_name
		},
		categories,
		expenses,
		reflection: refRows[0]?.note ?? "",
		year,
		month
	};
}
var monthInput = object({
	year: number().int().min(2020).max(2100),
	month: number().int().min(1).max(12)
});
var getMonthSnapshot_createServerFn_handler = createServerRpc({
	id: "8984b0591b8ab9d07d3b32d585ebb125ba4ef8a85505fa127debc9416091e214",
	name: "getMonthSnapshot",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => getMonthSnapshot.__executeServer(opts));
var getMonthSnapshot = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((d) => monthInput.parse(d)).handler(getMonthSnapshot_createServerFn_handler, async ({ context, data }) => {
	return loadSnapshot(await getSql(), context.userId, data.year, data.month);
});
var createHouseholdInput = object({
	selfName: string().trim().min(1).max(40),
	partnerName: string().trim().min(1).max(40),
	monthlyIncome: number().min(0).max(1e7),
	savingsGoal: number().min(0).max(1e7)
});
var createHousehold_createServerFn_handler = createServerRpc({
	id: "6cbedb87fce0627f7808c61bf0e4b928702f39a5e29b23d13ff00f659c8f59ef",
	name: "createHousehold",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => createHousehold.__executeServer(opts));
var createHousehold = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => createHouseholdInput.parse(d)).handler(createHousehold_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (await membership(sql, context.userId)) throw new Error("لديك بيت مسجّل بالفعل");
	const householdId = crypto.randomUUID();
	const selfId = crypto.randomUUID();
	const partnerId = crypto.randomUUID();
	let code = joinCode();
	for (let i = 0; i < 5; i += 1) {
		if ((await sql`select id from households where join_code = ${code} limit 1`).length === 0) break;
		code = joinCode();
	}
	await sql`
      insert into households (id, monthly_income, savings_goal, join_code)
      values (${householdId}, ${data.monthlyIncome}, ${data.savingsGoal}, ${code})
    `;
	await sql`
      insert into household_members (id, household_id, name, sort_order)
      values
        (${selfId}, ${householdId}, ${data.selfName}, 0),
        (${partnerId}, ${householdId}, ${data.partnerName}, 1)
    `;
	await sql`
      insert into household_users (user_id, household_id, member_id)
      values (${context.userId}, ${householdId}, ${selfId})
    `;
	for (let i = 0; i < DEFAULT_CATEGORIES.length; i += 1) {
		const c = DEFAULT_CATEGORIES[i];
		await sql`
        insert into categories (id, household_id, name, kind, monthly_limit, sort_order)
        values (${crypto.randomUUID()}, ${householdId}, ${c.name}, ${c.kind}, ${c.monthlyLimit}, ${i})
      `;
	}
	const cats = await sql`
      select id, sort_order from categories
      where household_id = ${householdId}
      order by sort_order asc
    `;
	const { year, month, day } = cairoParts();
	const memberIds = [selfId, partnerId];
	for (const row of DEMO_EXPENSES) {
		const useDay = Math.min(row.day, day);
		const cat = cats[row.categoryIndex];
		if (!cat) continue;
		const when = cairoLocalToDate(year, month, useDay, row.hour, row.minute);
		const mid = memberIds[row.memberIndex];
		await sql`
        insert into expenses (
          id, household_id, category_id, description, amount, occurred_at,
          created_by_member_id, updated_by_member_id
        ) values (
          ${crypto.randomUUID()}, ${householdId}, ${cat.id}, ${row.description},
          ${row.amount}, ${when.toISOString()}::timestamptz, ${mid}, ${mid}
        )
      `;
	}
	return {
		householdId,
		joinCode: code
	};
});
var joinInput = object({
	code: string().trim().min(4).max(12),
	memberId: string().uuid()
});
var joinHousehold_createServerFn_handler = createServerRpc({
	id: "839a9f3e14bae7a5a38bccafbf1847598e84a2ff39889f1f558e3de84ecb0d97",
	name: "joinHousehold",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => joinHousehold.__executeServer(opts));
var joinHousehold = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => joinInput.parse(d)).handler(joinHousehold_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (await membership(sql, context.userId)) throw new Error("أنت بالفعل ضمن بيت");
	const house = (await sql`
      select id from households where join_code = ${data.code.trim().toUpperCase()} limit 1
    `)[0];
	if (!house) throw new Error("رمز الانضمام غير صحيح");
	if (!(await sql`
      select id from household_members where household_id = ${house.id} and id = ${data.memberId}
    `)[0]) throw new Error("الاسم المختار غير موجود في هذا البيت");
	const taken = await sql`
      select user_id from household_users where member_id = ${data.memberId} limit 1
    `;
	if (taken[0] && taken[0].user_id !== context.userId) throw new Error("هذا الاسم مرتبط بحساب آخر");
	await sql`
      insert into household_users (user_id, household_id, member_id)
      values (${context.userId}, ${house.id}, ${data.memberId})
    `;
	return { householdId: house.id };
});
var lookupJoinCode_createServerFn_handler = createServerRpc({
	id: "db88a72b5d1365b39dd8901c0d748c1959dc70b11a5dcb8718f2acf17a9348f2",
	name: "lookupJoinCode",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => lookupJoinCode.__executeServer(opts));
var lookupJoinCode = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((d) => object({ code: string().trim().min(4).max(12) }).parse(d)).handler(lookupJoinCode_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const houses = await sql`
      select id from households where join_code = ${data.code.trim().toUpperCase()} limit 1
    `;
	if (!houses[0]) return {
		found: false,
		members: []
	};
	return {
		found: true,
		members: await loadMembers(sql, houses[0].id)
	};
});
var addExpenseInput = object({
	description: string().trim().min(1).max(120),
	amount: number().positive().max(1e6),
	categoryId: string().uuid()
});
var addExpense_createServerFn_handler = createServerRpc({
	id: "5b69e2d8ed6b35172744bc9f4d23b4f4e8e6b5eb24aa2b2332eeb1804aab6986",
	name: "addExpense",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => addExpense.__executeServer(opts));
var addExpense = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => addExpenseInput.parse(d)).handler(addExpense_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const mine = await membership(sql, context.userId);
	if (!mine) throw new Error("لا يوجد بيت مرتبط بحسابك");
	if (!(await sql`
      select id from categories
      where id = ${data.categoryId} and household_id = ${mine.household_id} and archived = false
    `)[0]) throw new Error("الفئة غير موجودة");
	const id = crypto.randomUUID();
	await sql`
      insert into expenses (
        id, household_id, category_id, description, amount,
        created_by_member_id, updated_by_member_id
      ) values (
        ${id}, ${mine.household_id}, ${data.categoryId}, ${data.description},
        ${data.amount}, ${mine.member_id}, ${mine.member_id}
      )
    `;
	return { id };
});
var updateExpenseInput = object({
	id: string().uuid(),
	description: string().trim().min(1).max(120),
	amount: number().positive().max(1e6),
	categoryId: string().uuid()
});
var updateExpense_createServerFn_handler = createServerRpc({
	id: "6955b121520578495a4fc6c8854ed9363e5c635ae1755dcb2c1fa992f0f310b8",
	name: "updateExpense",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => updateExpense.__executeServer(opts));
var updateExpense = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => updateExpenseInput.parse(d)).handler(updateExpense_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const mine = await membership(sql, context.userId);
	if (!mine) throw new Error("لا يوجد بيت مرتبط بحسابك");
	await sql`
      update expenses e
      set
        description = ${data.description},
        amount = ${data.amount},
        category_id = ${data.categoryId},
        updated_by_member_id = ${mine.member_id},
        updated_at = now()
      where e.id = ${data.id}
        and e.household_id = ${mine.household_id}
        and exists (
          select 1 from categories c
          where c.id = ${data.categoryId}
            and c.household_id = ${mine.household_id}
        )
    `;
	return { ok: true };
});
var deleteExpense_createServerFn_handler = createServerRpc({
	id: "9651f52a3139b4505581381bef5aa057882dd433aacf30921c85e9cdc0823af4",
	name: "deleteExpense",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => deleteExpense.__executeServer(opts));
var deleteExpense = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => object({ id: string().uuid() }).parse(d)).handler(deleteExpense_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const mine = await membership(sql, context.userId);
	if (!mine) throw new Error("لا يوجد بيت مرتبط بحسابك");
	await sql`
      delete from expenses
      where id = ${data.id} and household_id = ${mine.household_id}
    `;
	return { ok: true };
});
var upsertCategoryInput = object({
	id: string().uuid().optional(),
	name: string().trim().min(1).max(40),
	kind: _enum([
		"necessity",
		"extra",
		"unexpected"
	]),
	monthlyLimit: number().min(0).max(1e7)
});
var upsertCategory_createServerFn_handler = createServerRpc({
	id: "b0b1727e84f67582f68628132c96326e6ace9aef419779165356c66bd2315bb4",
	name: "upsertCategory",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => upsertCategory.__executeServer(opts));
var upsertCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => upsertCategoryInput.parse(d)).handler(upsertCategory_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const mine = await membership(sql, context.userId);
	if (!mine) throw new Error("لا يوجد بيت مرتبط بحسابك");
	if (data.id) {
		await sql`
        update categories
        set name = ${data.name}, kind = ${data.kind}, monthly_limit = ${data.monthlyLimit}
        where id = ${data.id} and household_id = ${mine.household_id}
      `;
		return { id: data.id };
	}
	const next = num((await sql`
      select max(sort_order) as m from categories where household_id = ${mine.household_id}
    `)[0]?.m) + 1;
	const id = crypto.randomUUID();
	await sql`
      insert into categories (id, household_id, name, kind, monthly_limit, sort_order)
      values (${id}, ${mine.household_id}, ${data.name}, ${data.kind}, ${data.monthlyLimit}, ${next})
    `;
	return { id };
});
var archiveCategory_createServerFn_handler = createServerRpc({
	id: "719183275fc8bd35f35de0c1291f4f2edebc8bd954accf2370a9faac45997438",
	name: "archiveCategory",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => archiveCategory.__executeServer(opts));
var archiveCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => object({ id: string().uuid() }).parse(d)).handler(archiveCategory_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const mine = await membership(sql, context.userId);
	if (!mine) throw new Error("لا يوجد بيت مرتبط بحسابك");
	await sql`
      update categories
      set archived = true
      where id = ${data.id} and household_id = ${mine.household_id}
    `;
	return { ok: true };
});
var updateHouseholdInput = object({
	monthlyIncome: number().min(0).max(1e7),
	savingsGoal: number().min(0).max(1e7),
	members: array(object({
		id: string().uuid(),
		name: string().trim().min(1).max(40)
	})).min(2).max(2)
});
var updateHousehold_createServerFn_handler = createServerRpc({
	id: "ed4635fd997e195b126aa86fec6dfe1cb5c6a770eaa3641b2efc7c595521adc8",
	name: "updateHousehold",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => updateHousehold.__executeServer(opts));
var updateHousehold = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => updateHouseholdInput.parse(d)).handler(updateHousehold_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const mine = await membership(sql, context.userId);
	if (!mine) throw new Error("لا يوجد بيت مرتبط بحسابك");
	await sql`
      update households
      set monthly_income = ${data.monthlyIncome}, savings_goal = ${data.savingsGoal}
      where id = ${mine.household_id}
    `;
	for (const m of data.members) await sql`
        update household_members
        set name = ${m.name}
        where id = ${m.id} and household_id = ${mine.household_id}
      `;
	return { ok: true };
});
var setActiveMember_createServerFn_handler = createServerRpc({
	id: "986026a378600f0bad2a8d8c86c257c15cf75ea2638aab3b28c39bba06d5aecf",
	name: "setActiveMember",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => setActiveMember.__executeServer(opts));
var setActiveMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => object({ memberId: string().uuid() }).parse(d)).handler(setActiveMember_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const mine = await membership(sql, context.userId);
	if (!mine) throw new Error("لا يوجد بيت مرتبط بحسابك");
	if (!(await sql`
      select id from household_members
      where id = ${data.memberId} and household_id = ${mine.household_id}
    `)[0]) throw new Error("عضو غير موجود");
	await sql`
      update household_users
      set member_id = ${data.memberId}
      where user_id = ${context.userId} and household_id = ${mine.household_id}
    `;
	return { ok: true };
});
var saveReflectionInput = object({
	year: number().int(),
	month: number().int().min(1).max(12),
	note: string().max(800)
});
var saveReflection_createServerFn_handler = createServerRpc({
	id: "76324e27a95560ca3a84f5d6a837928650e6f602e60db4b82e8cdf7694f725a9",
	name: "saveReflection",
	filename: "src/lib/masroufi/queries.ts"
}, (opts) => saveReflection.__executeServer(opts));
var saveReflection = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => saveReflectionInput.parse(d)).handler(saveReflection_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const mine = await membership(sql, context.userId);
	if (!mine) throw new Error("لا يوجد بيت مرتبط بحسابك");
	await sql`
      insert into reflections (household_id, year, month, note, updated_by_member_id, updated_at)
      values (${mine.household_id}, ${data.year}, ${data.month}, ${data.note}, ${mine.member_id}, now())
      on conflict (household_id, year, month)
      do update set
        note = excluded.note,
        updated_by_member_id = excluded.updated_by_member_id,
        updated_at = now()
    `;
	return { ok: true };
});
//#endregion
export { addExpense_createServerFn_handler, archiveCategory_createServerFn_handler, createHousehold_createServerFn_handler, deleteExpense_createServerFn_handler, getMonthSnapshot_createServerFn_handler, joinHousehold_createServerFn_handler, lookupJoinCode_createServerFn_handler, saveReflection_createServerFn_handler, setActiveMember_createServerFn_handler, updateExpense_createServerFn_handler, updateHousehold_createServerFn_handler, upsertCategory_createServerFn_handler };
