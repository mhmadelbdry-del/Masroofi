import { d as useRouterState, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Scale, i as Settings, l as LayoutGrid, o as Receipt } from "../_libs/lucide-react.mjs";
import { c as cn, m as useSnapshot, o as Logo } from "./label-C-91Zdo4.mjs";
import { t as MemberDot } from "./member-dot-BcqBOtJn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-UNqL5uTK.js
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		to: "/",
		label: "ملخص الشهر",
		icon: LayoutGrid
	},
	{
		to: "/expenses",
		label: "المصروفات",
		icon: Receipt
	},
	{
		to: "/budget",
		label: "حدود الميزانية",
		icon: Scale
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { data } = useSnapshot();
	const me = data?.me;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh w-full max-w-lg flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border/70 bg-bg/90 px-4 py-3 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
					withWord: true,
					size: "sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5",
					children: [me ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 rounded-full bg-surface py-1 pr-1 pl-3 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted",
							children: me.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberDot, {
							name: me.name,
							size: "sm",
							active: true
						})]
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/settings",
						className: cn("grid size-11 place-items-center rounded-full text-muted hover:bg-bg-warm", pathname === "/settings" && "bg-primary-soft text-primary"),
						"aria-label": "الإعدادات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 px-4 pt-4 pb-32",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "pointer-events-none fixed inset-x-0 bottom-0 z-30 flex justify-center px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-auto flex w-full max-w-md items-center justify-around rounded-xl bg-surface px-2 py-2 shadow-nav",
					children: TABS.map((tab) => {
						const active = pathname === tab.to;
						const Icon = tab.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: tab.to,
							className: cn("flex min-h-11 min-w-20 flex-1 flex-col items-center justify-center gap-0.5 rounded-lg px-2 py-1 text-xs font-medium transition-colors duration-150", active ? "bg-primary-soft text-primary" : "text-subtle hover:text-fg"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.2 : 1.8
							}), tab.label]
						}, tab.to);
					})
				})
			})
		]
	});
}
//#endregion
export { AppShell as t };
