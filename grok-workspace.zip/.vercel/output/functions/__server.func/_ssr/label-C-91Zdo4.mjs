import "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { r as cairoParts, t as authMiddleware } from "./format-BkDqXsC0.mjs";
import { D as _enum, F as object, P as number, R as string, k as array } from "../_libs/@better-auth/core+[...].mjs";
import { t as authClient } from "./client-B40BzJxt.mjs";
import { n as Wallet } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as createSsrRpc } from "./router-Dqc0bUN5.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function isUnauthorized(error) {
	if (!error || typeof error !== "object") return false;
	const e = error;
	return e.status === 401 || e.message === "Unauthorized" || e.name === "UnauthorizedError";
}
var now = cairoParts();
var useMonth = create((set) => ({
	year: now.year,
	month: now.month,
	setMonth: (year, month) => set({
		year,
		month
	})
}));
var monthInput = object({
	year: number().int().min(2020).max(2100),
	month: number().int().min(1).max(12)
});
var getMonthSnapshot = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((d) => monthInput.parse(d)).handler(createSsrRpc("8984b0591b8ab9d07d3b32d585ebb125ba4ef8a85505fa127debc9416091e214"));
var createHouseholdInput = object({
	selfName: string().trim().min(1).max(40),
	partnerName: string().trim().min(1).max(40),
	monthlyIncome: number().min(0).max(1e7),
	savingsGoal: number().min(0).max(1e7)
});
var createHousehold = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => createHouseholdInput.parse(d)).handler(createSsrRpc("6cbedb87fce0627f7808c61bf0e4b928702f39a5e29b23d13ff00f659c8f59ef"));
var joinInput = object({
	code: string().trim().min(4).max(12),
	memberId: string().uuid()
});
var joinHousehold = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => joinInput.parse(d)).handler(createSsrRpc("839a9f3e14bae7a5a38bccafbf1847598e84a2ff39889f1f558e3de84ecb0d97"));
var lookupJoinCode = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((d) => object({ code: string().trim().min(4).max(12) }).parse(d)).handler(createSsrRpc("db88a72b5d1365b39dd8901c0d748c1959dc70b11a5dcb8718f2acf17a9348f2"));
var addExpenseInput = object({
	description: string().trim().min(1).max(120),
	amount: number().positive().max(1e6),
	categoryId: string().uuid()
});
var addExpense = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => addExpenseInput.parse(d)).handler(createSsrRpc("5b69e2d8ed6b35172744bc9f4d23b4f4e8e6b5eb24aa2b2332eeb1804aab6986"));
var updateExpenseInput = object({
	id: string().uuid(),
	description: string().trim().min(1).max(120),
	amount: number().positive().max(1e6),
	categoryId: string().uuid()
});
var updateExpense = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => updateExpenseInput.parse(d)).handler(createSsrRpc("6955b121520578495a4fc6c8854ed9363e5c635ae1755dcb2c1fa992f0f310b8"));
var deleteExpense = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => object({ id: string().uuid() }).parse(d)).handler(createSsrRpc("9651f52a3139b4505581381bef5aa057882dd433aacf30921c85e9cdc0823af4"));
var upsertCategoryInput = object({
	id: string().uuid().optional(),
	name: string().trim().min(1).max(40),
	kind: _enum([
		"necessity",
		"extra",
		"unexpected"
	]),
	monthlyLimit: number().min(0).max(1e7)
});
var upsertCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => upsertCategoryInput.parse(d)).handler(createSsrRpc("b0b1727e84f67582f68628132c96326e6ace9aef419779165356c66bd2315bb4"));
var archiveCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => object({ id: string().uuid() }).parse(d)).handler(createSsrRpc("719183275fc8bd35f35de0c1291f4f2edebc8bd954accf2370a9faac45997438"));
var updateHouseholdInput = object({
	monthlyIncome: number().min(0).max(1e7),
	savingsGoal: number().min(0).max(1e7),
	members: array(object({
		id: string().uuid(),
		name: string().trim().min(1).max(40)
	})).min(2).max(2)
});
var updateHousehold = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => updateHouseholdInput.parse(d)).handler(createSsrRpc("ed4635fd997e195b126aa86fec6dfe1cb5c6a770eaa3641b2efc7c595521adc8"));
var setActiveMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => object({ memberId: string().uuid() }).parse(d)).handler(createSsrRpc("986026a378600f0bad2a8d8c86c257c15cf75ea2638aab3b28c39bba06d5aecf"));
var saveReflectionInput = object({
	year: number().int(),
	month: number().int().min(1).max(12),
	note: string().max(800)
});
var saveReflection = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => saveReflectionInput.parse(d)).handler(createSsrRpc("76324e27a95560ca3a84f5d6a837928650e6f602e60db4b82e8cdf7694f725a9"));
function fail(error, fallback) {
	if (isUnauthorized(error)) {
		toast.error("انتهت الجلسة — سجّل الدخول مرة أخرى");
		return;
	}
	const message = error instanceof Error ? error.message : fallback;
	toast.error(message);
}
function useSnapshot() {
	const { year, month } = useMonth();
	return useQuery({
		queryKey: [
			"snapshot",
			year,
			month
		],
		queryFn: () => getMonthSnapshot({ data: {
			year,
			month
		} }),
		refetchInterval: 8e3,
		refetchOnWindowFocus: true,
		retry: (count, error) => !isUnauthorized(error) && count < 2
	});
}
function useMasroufiMutations() {
	const qc = useQueryClient();
	const invalidate = () => qc.invalidateQueries({ queryKey: ["snapshot"] });
	return {
		add: useMutation({
			mutationFn: (data) => addExpense({ data }),
			onSuccess: () => {
				toast.success("تم حفظ المصروف");
				invalidate();
			},
			onError: (e) => fail(e, "تعذر حفظ المصروف")
		}),
		update: useMutation({
			mutationFn: (data) => updateExpense({ data }),
			onSuccess: () => {
				toast.success("تم تعديل المصروف");
				invalidate();
			},
			onError: (e) => fail(e, "تعذر التعديل")
		}),
		remove: useMutation({
			mutationFn: (id) => deleteExpense({ data: { id } }),
			onSuccess: () => {
				toast.success("حُذف المصروف");
				invalidate();
			},
			onError: (e) => fail(e, "تعذر الحذف")
		}),
		saveCat: useMutation({
			mutationFn: (data) => upsertCategory({ data }),
			onSuccess: () => {
				toast.success("تم حفظ الفئة");
				invalidate();
			},
			onError: (e) => fail(e, "تعذر حفظ الفئة")
		}),
		hideCat: useMutation({
			mutationFn: (id) => archiveCategory({ data: { id } }),
			onSuccess: () => {
				toast.success("أُزيلت الفئة من القائمة");
				invalidate();
			},
			onError: (e) => fail(e, "تعذر حذف الفئة")
		}),
		household: useMutation({
			mutationFn: (data) => updateHousehold({ data }),
			onSuccess: () => {
				toast.success("تم حفظ إعدادات البيت");
				invalidate();
			},
			onError: (e) => fail(e, "تعذر الحفظ")
		}),
		member: useMutation({
			mutationFn: (memberId) => setActiveMember({ data: { memberId } }),
			onSuccess: () => {
				toast.success("تم تثبيت المستخدم الحالي");
				invalidate();
			},
			onError: (e) => fail(e, "تعذر التبديل")
		}),
		reflection: useMutation({
			mutationFn: (data) => saveReflection({ data }),
			onSuccess: () => {
				toast.success("حُفظ التأمل الشهري");
				invalidate();
			},
			onError: (e) => fail(e, "تعذر حفظ التأمل")
		}),
		create: useMutation({
			mutationFn: (data) => createHousehold({ data }),
			onSuccess: () => {
				invalidate();
			},
			onError: (e) => fail(e, "تعذر إنشاء البيت")
		}),
		join: useMutation({
			mutationFn: (data) => joinHousehold({ data }),
			onSuccess: () => {
				invalidate();
			},
			onError: (e) => fail(e, "تعذر الانضمام")
		}),
		invalidate
	};
}
function useJoinLookup(code) {
	const trimmed = code.trim();
	return useQuery({
		queryKey: ["join", trimmed],
		queryFn: () => lookupJoinCode({ data: { code: trimmed } }),
		enabled: trimmed.length >= 4
	});
}
function Logo({ size = "md", withWord = false, invert = false }) {
	const box = size === "lg" ? "size-12 rounded-lg" : size === "sm" ? "size-8 rounded-md" : "size-10 rounded-md";
	const icon = size === "lg" ? "size-6" : size === "sm" ? "size-4" : "size-5";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("grid place-items-center", box, invert ? "bg-surface/15 text-hero-fg" : "bg-primary text-primary-fg"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {
				className: icon,
				strokeWidth: 1.75
			})
		}), withWord ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("text-lg font-semibold tracking-tight", invert ? "text-hero-fg" : "text-fg"),
			children: "مصروفي"
		}) : null]
	});
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
function Splash({ label = "جاري التحميل…" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-4 bg-bg px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
			size: "lg",
			withWord: true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		})]
	});
}
function AuthGate({ children }) {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function HouseholdGate({ children }) {
	const { data, isPending, error } = useSnapshot();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, { label: "نجهّز دفتر البيت…" });
	if (error && isUnauthorized(error)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 px-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-fg",
			children: "تعذر تحميل البيانات"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: error.message
		})]
	});
	if (!data?.household) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/onboarding" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[transform,background-color,opacity,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:bg-primary/90",
			secondary: "bg-primary-soft text-primary hover:bg-primary-soft/80",
			outline: "border border-border-strong bg-surface text-fg hover:bg-surface-2",
			ghost: "text-fg hover:bg-bg-warm",
			danger: "bg-danger text-primary-fg hover:bg-danger/90",
			hero: "bg-surface/15 text-hero-fg hover:bg-surface/25"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md border border-border bg-surface px-3 text-base text-fg shadow-none outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-subtle focus:border-primary focus:ring-2 focus:ring-ring/20 disabled:opacity-50", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("block text-sm font-medium text-muted", className),
		...props
	});
}
//#endregion
export { Label as a, cn as c, useJoinLookup as d, useMasroufiMutations as f, Input as i, useCurrentUser as l, useSnapshot as m, Button as n, Logo as o, useMonth as p, HouseholdGate as r, Splash as s, AuthGate as t, useCurrentUserState as u };
