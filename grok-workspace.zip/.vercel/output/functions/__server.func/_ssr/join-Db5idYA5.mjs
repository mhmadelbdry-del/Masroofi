import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate, v as Link, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Label, c as cn, d as useJoinLookup, f as useMasroufiMutations, i as Input, m as useSnapshot, n as Button, o as Logo, s as Splash, t as AuthGate } from "./label-C-91Zdo4.mjs";
import { t as MemberDot } from "./member-dot-BcqBOtJn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/join-Db5idYA5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function JoinPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JoinForm, {}) });
}
function JoinForm() {
	const { data, isPending } = useSnapshot();
	const nav = useNavigate();
	const mut = useMasroufiMutations();
	const [code, setCode] = (0, import_react.useState)("");
	const [memberId, setMemberId] = (0, import_react.useState)("");
	const lookup = useJoinLookup(code);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (data?.household) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	const members = lookup.data?.found ? lookup.data.members : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { withWord: true }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-5 text-2xl font-semibold",
				children: "الانضمام لدفتر البيت"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 mb-5 text-sm text-muted",
				children: "أدخل الرمز الذي وصلك، ثم اختر اسمك."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "paper-card space-y-4 rounded-xl p-5",
				onSubmit: async (e) => {
					e.preventDefault();
					if (!memberId) return;
					try {
						await mut.join.mutateAsync({
							code,
							memberId
						});
						await nav({ to: "/" });
					} catch {}
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "code",
							children: "رمز الانضمام"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "code",
							value: code,
							onChange: (e) => {
								setCode(e.target.value.toUpperCase());
								setMemberId("");
							},
							placeholder: "K7M2QX",
							dir: "ltr",
							className: "text-center tracking-widest"
						})]
					}),
					lookup.data?.found === false && code.trim().length >= 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: "لا بيت بهذا الرمز."
					}) : null,
					members.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "من أنت؟" }), members.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: m.claimed,
							onClick: () => setMemberId(m.id),
							className: cn("flex w-full items-center justify-between rounded-md px-3 py-3", memberId === m.id ? "bg-primary text-primary-fg" : "bg-bg-warm", m.claimed && "opacity-50"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberDot, {
									name: m.name,
									size: "sm",
									active: memberId === m.id
								}), m.name]
							}), m.claimed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs",
								children: "مرتبط بحساب"
							}) : null]
						}, m.id))]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "w-full",
						disabled: !memberId || mut.join.isPending,
						children: mut.join.isPending ? "جارٍ الانضمام…" : "انضم وزامن الدفتر"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-5 text-center text-sm text-muted",
				children: [
					"لا رمز لديك؟",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/onboarding",
						className: "font-medium text-primary",
						children: "أنشئ بيتاً جديداً"
					})
				]
			})
		]
	});
}
//#endregion
export { JoinPage as component };
