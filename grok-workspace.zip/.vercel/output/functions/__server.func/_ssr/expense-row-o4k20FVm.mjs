import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as formatExpenseWhen, o as formatMoney } from "./format-BkDqXsC0.mjs";
import { a as Label, i as Input, n as Button } from "./label-C-91Zdo4.mjs";
import { t as MemberDot } from "./member-dot-BcqBOtJn.mjs";
import { r as KIND_LABEL } from "./types-5Gk2wD6h.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/expense-row-o4k20FVm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ExpenseForm({ categories, me, pending, onSubmit, initial, submitLabel = "حفظ المصروف" }) {
	const [description, setDescription] = (0, import_react.useState)(initial?.description ?? "");
	const [amount, setAmount] = (0, import_react.useState)(initial ? String(initial.amount) : "");
	const [categoryId, setCategoryId] = (0, import_react.useState)(initial?.categoryId ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-3",
		onSubmit: (e) => {
			e.preventDefault();
			const value = Number(amount);
			if (!description.trim() || !categoryId || !Number.isFinite(value) || value <= 0) return;
			onSubmit({
				description: description.trim(),
				amount: value,
				categoryId
			});
			if (!initial) {
				setDescription("");
				setAmount("");
			}
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "exp-desc",
					children: "بيان المصروف"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "exp-desc",
					value: description,
					onChange: (e) => setDescription(e.target.value),
					placeholder: "مثال: تموينات، سوبرماركت، وقود",
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "exp-amount",
						children: "المبلغ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "exp-amount",
						inputMode: "decimal",
						type: "number",
						min: "0.01",
						step: "0.01",
						value: amount,
						onChange: (e) => setAmount(e.target.value),
						placeholder: "0.00",
						required: true
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "exp-cat",
						children: "الفئة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "exp-cat",
						value: categoryId,
						onChange: (e) => setCategoryId(e.target.value),
						required: true,
						className: "flex h-11 w-full rounded-md border border-border bg-surface px-3 text-sm text-fg outline-none focus:border-primary focus:ring-2 focus:ring-ring/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "اختر الفئة…"
						}), categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 rounded-md bg-primary-soft/60 px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: "يُسجَّل تلقائياً باسم المستخدم الحالي"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2 text-sm font-medium text-primary",
					children: [me.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberDot, {
						name: me.name,
						size: "sm",
						active: true
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "w-full",
				disabled: pending,
				children: pending ? "جارٍ الحفظ…" : submitLabel
			})
		]
	});
}
function ExpenseRow({ expense, onClick }) {
	const when = formatExpenseWhen(expense.occurredAt);
	const edited = expense.updatedByMemberId !== expense.createdByMemberId;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "paper-card flex w-full items-start justify-between gap-3 rounded-lg p-4 text-right transition-[transform] duration-150 active:scale-[0.99]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-medium text-fg",
					children: expense.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-subtle",
					children: [
						expense.categoryName,
						" · ",
						KIND_LABEL[expense.categoryKind],
						" · ",
						when.date,
						" (",
						when.time,
						")"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted",
					children: [
						"سجّله ",
						expense.createdByName,
						edited ? ` · آخر تعديل: ${expense.updatedByName}` : ""
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "num shrink-0 text-base font-semibold text-fg",
			children: formatMoney(expense.amount, { fixed: true })
		})]
	});
}
//#endregion
export { ExpenseRow as n, ExpenseForm as t };
